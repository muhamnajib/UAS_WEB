<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Belajar PHP</title>
</head>
<body>

<?php

var_dump(12<14); // bool(true)
echo "<br />";
var_dump(14<14); // bool(false)
echo "<br />";
var_dump(14<=14); // bool(true)
echo "<br />";
var_dump(10<>14); // bool(true)
echo "<br />";
var_dump(15==10); // bool(false)
echo "<br />";
var_dump(10===10); // bool(true)
echo "<br />";
var_dump(150===1.5e2); // bool(true)

?>


</body>
</html>