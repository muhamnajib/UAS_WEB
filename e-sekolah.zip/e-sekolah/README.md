# e-sekolah
Contoh script sederhana dengan PHP dan MySQL untuk input nilai Mata Pelajaran oleh guru pengampu. 
Login dengan multiuser dengan hak akses sesuai level
