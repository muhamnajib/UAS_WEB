  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel (optional) -->
      <div class="user-panel">
         <div class="logo" ><img src="../assets/images/uinjkt.png" alt="Logo e-Sekolah" /></div>
         <div class="logo-title">MTs e-Sekolah</div>
      </div>

      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>